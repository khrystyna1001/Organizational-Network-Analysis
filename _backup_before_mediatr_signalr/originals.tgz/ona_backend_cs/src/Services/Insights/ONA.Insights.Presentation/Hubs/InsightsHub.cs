using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace ONA.Insights.Presentation.Hubs;

/// <summary>
/// Real-time notifications for recommendation generation and responses.
/// Clients connect with a JWT via <c>access_token</c> query parameter.
/// </summary>
[Authorize]
public sealed class InsightsHub : Hub
{
    public const string RecommendationsGeneratedMethod = "recommendations-generated";
    public const string RecommendationRespondedMethod = "recommendation-responded";

    public Task JoinAnalysisRunGroup(string analysisRunId) =>
        Groups.AddToGroupAsync(Context.ConnectionId, $"run:{analysisRunId}");

    public Task LeaveAnalysisRunGroup(string analysisRunId) =>
        Groups.RemoveFromGroupAsync(Context.ConnectionId, $"run:{analysisRunId}");
}
