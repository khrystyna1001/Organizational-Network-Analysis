using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace ONA.Analysis.Presentation.Hubs;

/// <summary>
/// Real-time notifications for analysis run lifecycle. Clients connect with a JWT
/// (via <c>access_token</c> query parameter, since browsers cannot set headers on WebSocket).
/// The hub is used by the UI to refresh the runs list when a run completes or fails.
/// </summary>
[Authorize]
public sealed class AnalysisHub : Hub
{
    public const string RunCompletedMethod = "analysis-run-completed";
    public const string RunFailedMethod = "analysis-run-failed";

    /// <summary>Join a board-specific group so only relevant clients get notified.</summary>
    public Task JoinBoardGroup(string boardId) =>
        Groups.AddToGroupAsync(Context.ConnectionId, $"board:{boardId}");

    public Task LeaveBoardGroup(string boardId) =>
        Groups.RemoveFromGroupAsync(Context.ConnectionId, $"board:{boardId}");
}
